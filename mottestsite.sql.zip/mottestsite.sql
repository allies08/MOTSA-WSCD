-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2018 at 06:44 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mottestsite`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-08-12 06:36:57', '2018-08-12 06:36:57', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/mot', 'yes'),
(2, 'home', 'http://localhost/mot', 'yes'),
(3, 'blogname', 'MOT South Africa', 'yes'),
(4, 'blogdescription', 'Show courage!', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'shuaib.allie@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:53:\"C:\\xampp\\htdocs\\mot/wp-content/themes/motSA/style.css\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'motSA', 'yes'),
(41, 'stylesheet', 'motSA', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '35', 'yes'),
(84, 'page_on_front', '41', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:73:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:11:\"edit_blocks\";b:1;s:18:\"edit_others_blocks\";b:1;s:14:\"publish_blocks\";b:1;s:19:\"read_private_blocks\";b:1;s:11:\"read_blocks\";b:1;s:13:\"delete_blocks\";b:1;s:21:\"delete_private_blocks\";b:1;s:23:\"delete_published_blocks\";b:1;s:20:\"delete_others_blocks\";b:1;s:19:\"edit_private_blocks\";b:1;s:21:\"edit_published_blocks\";b:1;s:13:\"create_blocks\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:46:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:11:\"edit_blocks\";b:1;s:18:\"edit_others_blocks\";b:1;s:14:\"publish_blocks\";b:1;s:19:\"read_private_blocks\";b:1;s:11:\"read_blocks\";b:1;s:13:\"delete_blocks\";b:1;s:21:\"delete_private_blocks\";b:1;s:23:\"delete_published_blocks\";b:1;s:20:\"delete_others_blocks\";b:1;s:19:\"edit_private_blocks\";b:1;s:21:\"edit_published_blocks\";b:1;s:13:\"create_blocks\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:17:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:11:\"edit_blocks\";b:1;s:14:\"publish_blocks\";b:1;s:11:\"read_blocks\";b:1;s:13:\"delete_blocks\";b:1;s:23:\"delete_published_blocks\";b:1;s:21:\"edit_published_blocks\";b:1;s:13:\"create_blocks\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:6:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:11:\"read_blocks\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1535452620;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1535481420;a:3:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1535524647;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535524698;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1534066255;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}s:18:\"nav_menu_locations\";a:0:{}}', 'yes'),
(116, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1535439690;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:0:{}}', 'no'),
(121, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1535439689;s:7:\"checked\";a:4:{s:5:\"motSA\";s:6:\"2.1.11\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(126, 'can_compress_scripts', '1', 'no'),
(140, 'recently_activated', 'a:1:{s:23:\"gutenberg/gutenberg.php\";i:1534056509;}', 'yes'),
(150, 'current_theme', 'WSCD', 'yes'),
(151, 'theme_mods_motSA', 'a:7:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:31:\"parallax_one_character_cyrillic\";b:1;s:33:\"parallax_one_character_vietnamese\";b:1;s:28:\"parallax_one_character_greek\";b:1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1534064255;s:4:\"data\";a:6:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:11:\"footer-area\";a:0:{}s:13:\"footer-area-2\";a:0:{}s:13:\"footer-area-3\";a:0:{}s:13:\"footer-area-4\";a:0:{}}}}', 'yes'),
(152, 'theme_switched', '', 'yes'),
(164, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(170, '_transient_timeout_-update-response', '3068130310', 'no'),
(171, '_transient_-update-response', 'O:8:\"stdClass\":1:{s:11:\"new_version\";s:6:\"2.1.11\";}', 'no'),
(173, 'theme_mods_twentyfifteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1534064279;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(174, '_site_transient_update_plugins', 'O:8:\"stdClass\":2:{s:12:\"last_checked\";i:1535439691;s:8:\"response\";N;}', 'no'),
(175, '_transient_twentyfifteen_categories', '1', 'yes'),
(179, 'WPLANG', '', 'yes'),
(180, 'new_admin_email', 'shuaib.allie@yahoo.com', 'yes'),
(196, '_site_transient_timeout_theme_roots', '1535441489', 'no'),
(197, '_site_transient_theme_roots', 'a:4:{s:5:\"motSA\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(198, '_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b', '1535483148', 'no'),
(199, '_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b', '<div class=\"rss-widget\"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: wordpress.org</p></div><div class=\"rss-widget\"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: planet.wordpress.org</p></div>', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_oembed_85fbb30061e6c2be3e051d8ebd59db5e', '<iframe src=\"https://player.vimeo.com/video/22439234?app_id=122963\" width=\"525\" height=\"295\" frameborder=\"0\" title=\"The Mountain\" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'),
(4, 5, '_oembed_time_85fbb30061e6c2be3e051d8ebd59db5e', '1534055932'),
(5, 3, '_wp_trash_meta_status', 'draft'),
(6, 3, '_wp_trash_meta_time', '1534059704'),
(7, 3, '_wp_desired_post_slug', 'privacy-policy'),
(8, 8, '_edit_last', '1'),
(9, 8, '_wp_page_template', 'default'),
(10, 8, '_edit_lock', '1535440020:1'),
(11, 10, '_edit_last', '1'),
(12, 10, '_wp_page_template', 'default'),
(13, 10, '_edit_lock', '1534059609:1'),
(14, 12, '_edit_last', '1'),
(15, 12, '_wp_page_template', 'default'),
(16, 12, '_edit_lock', '1534166268:1'),
(17, 14, '_edit_last', '1'),
(18, 14, '_edit_lock', '1534059658:1'),
(19, 14, '_wp_page_template', 'default'),
(20, 16, '_edit_last', '1'),
(21, 16, '_wp_page_template', 'default'),
(22, 16, '_edit_lock', '1534059703:1'),
(23, 2, '_edit_lock', '1534059735:1'),
(24, 2, '_edit_last', '1'),
(25, 19, '_wp_trash_meta_status', 'publish'),
(26, 19, '_wp_trash_meta_time', '1534060020'),
(27, 22, '_wp_attached_file', '2018/08/boardmotnorway-500x367.jpg'),
(28, 22, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:367;s:4:\"file\";s:34:\"2018/08/boardmotnorway-500x367.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"boardmotnorway-500x367-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"boardmotnorway-500x367-300x220.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:220;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:31:\"parallax-one-post-thumbnail-big\";a:4:{s:4:\"file\";s:34:\"boardmotnorway-500x367-500x340.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:340;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:34:\"parallax-one-post-thumbnail-mobile\";a:4:{s:4:\"file\";s:34:\"boardmotnorway-500x367-500x233.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:233;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:39:\"parallax-one-post-thumbnail-latest-news\";a:4:{s:4:\"file\";s:34:\"boardmotnorway-500x367-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:17:\"parallax_one_team\";a:4:{s:4:\"file\";s:34:\"boardmotnorway-500x367-268x273.jpg\";s:5:\"width\";i:268;s:6:\"height\";i:273;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"parallax_one_services\";a:4:{s:4:\"file\";s:32:\"boardmotnorway-500x367-60x62.jpg\";s:5:\"width\";i:60;s:6:\"height\";i:62;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:22:\"parallax_one_customers\";a:4:{s:4:\"file\";s:32:\"boardmotnorway-500x367-75x75.jpg\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(38, 25, '_menu_item_type', 'post_type'),
(39, 25, '_menu_item_menu_item_parent', '0'),
(40, 25, '_menu_item_object_id', '14'),
(41, 25, '_menu_item_object', 'page'),
(42, 25, '_menu_item_target', ''),
(43, 25, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(44, 25, '_menu_item_xfn', ''),
(45, 25, '_menu_item_url', ''),
(47, 26, '_menu_item_type', 'post_type'),
(48, 26, '_menu_item_menu_item_parent', '28'),
(49, 26, '_menu_item_object_id', '12'),
(50, 26, '_menu_item_object', 'page'),
(51, 26, '_menu_item_target', ''),
(52, 26, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(53, 26, '_menu_item_xfn', ''),
(54, 26, '_menu_item_url', ''),
(56, 27, '_menu_item_type', 'post_type'),
(57, 27, '_menu_item_menu_item_parent', '0'),
(58, 27, '_menu_item_object_id', '10'),
(59, 27, '_menu_item_object', 'page'),
(60, 27, '_menu_item_target', ''),
(61, 27, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(62, 27, '_menu_item_xfn', ''),
(63, 27, '_menu_item_url', ''),
(65, 28, '_menu_item_type', 'post_type'),
(66, 28, '_menu_item_menu_item_parent', '0'),
(67, 28, '_menu_item_object_id', '8'),
(68, 28, '_menu_item_object', 'page'),
(69, 28, '_menu_item_target', ''),
(70, 28, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(71, 28, '_menu_item_xfn', ''),
(72, 28, '_menu_item_url', ''),
(74, 29, '_menu_item_type', 'post_type'),
(75, 29, '_menu_item_menu_item_parent', '0'),
(76, 29, '_menu_item_object_id', '2'),
(77, 29, '_menu_item_object', 'page'),
(78, 29, '_menu_item_target', ''),
(79, 29, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(80, 29, '_menu_item_xfn', ''),
(81, 29, '_menu_item_url', ''),
(83, 30, '_edit_last', '1'),
(84, 30, '_edit_lock', '1535440052:1'),
(85, 33, '_edit_last', '1'),
(86, 33, '_edit_lock', '1535440455:1'),
(87, 35, '_edit_last', '1'),
(88, 35, '_edit_lock', '1535440475:1'),
(89, 37, '_menu_item_type', 'post_type'),
(90, 37, '_menu_item_menu_item_parent', '0'),
(91, 37, '_menu_item_object_id', '35'),
(92, 37, '_menu_item_object', 'page'),
(93, 37, '_menu_item_target', ''),
(94, 37, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(95, 37, '_menu_item_xfn', ''),
(96, 37, '_menu_item_url', ''),
(98, 38, '_edit_last', '1'),
(99, 38, '_edit_lock', '1535440564:1'),
(100, 40, '_menu_item_type', 'post_type'),
(101, 40, '_menu_item_menu_item_parent', '0'),
(102, 40, '_menu_item_object_id', '38'),
(103, 40, '_menu_item_object', 'page'),
(104, 40, '_menu_item_target', ''),
(105, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(106, 40, '_menu_item_xfn', ''),
(107, 40, '_menu_item_url', ''),
(110, 41, '_customize_changeset_uuid', 'b5a0dd4e-fcc7-4ea3-95f7-2b0b4eed0fa2'),
(111, 42, '_edit_lock', '1535440944:1'),
(112, 42, '_wp_trash_meta_status', 'publish'),
(113, 42, '_wp_trash_meta_time', '1535440946'),
(114, 41, '_edit_lock', '1535441599:1');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-08-12 06:36:57', '2018-08-12 06:36:57', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-08-12 06:36:57', '2018-08-12 06:36:57', '', 0, 'http://localhost/mot/?p=1', 0, 'post', '', 1),
(2, 1, '2018-08-12 06:36:57', '2018-08-12 06:36:57', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href=\"http://localhost/mot/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Our Partners', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-08-12 07:44:35', '2018-08-12 07:44:35', '', 0, 'http://localhost/mot/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-08-12 06:36:57', '2018-08-12 06:36:57', '<h2>Who we are</h2><p>Our website address is: http://localhost/mot.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2018-08-12 07:41:44', '2018-08-12 07:41:44', '', 0, 'http://localhost/mot/?page_id=3', 0, 'page', '', 0),
(5, 1, '2018-08-12 06:38:50', '0000-00-00 00:00:00', '<!-- wp:cover-image {\"url\":\"https://cldup.com/Fz-ASbo2s3.jpg\",\"align\":\"wide\"} -->\n<div class=\"wp-block-cover-image has-background-dim alignwide\" style=\"background-image:url(https://cldup.com/Fz-ASbo2s3.jpg)\"><p class=\"wp-block-cover-image-text\">Of Mountains &amp; Printing Presses</p></div>\n<!-- /wp:cover-image -->\n\n<!-- wp:paragraph -->\n<p>The goal of this new editor is to make adding rich content to WordPress simple and enjoyable. This whole post is composed of <em>pieces of content</em>—somewhat similar to LEGO bricks—that you can move around and interact with. Move your cursor around and you’ll notice the different blocks light up with outlines and arrows. Press the arrows to reposition blocks quickly, without fearing about losing things in the process of copying and pasting.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>What you are reading now is a <strong>text block</strong> the most basic block of all. The text block has its own controls to be moved freely around the post...</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"align\":\"right\"} -->\n<p style=\"text-align:right\">... like this one, which is right aligned.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Headings are separate blocks as well, which helps with the outline and organization of your content.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>A Picture is Worth a Thousand Words</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Handling images and media with the utmost care is a primary focus of the new editor. Hopefully, you’ll find aspects of adding captions or going full-width with your pictures much easier and robust than before.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"align\":\"center\"} -->\n<figure class=\"wp-block-image aligncenter\"><img src=\"https://cldup.com/cXyG__fTLN.jpg\" alt=\"Beautiful landscape\"/><figcaption>If your theme supports it, you’ll see the \"wide\" button on the image toolbar. Give it a try.</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Try selecting and removing or editing the caption, now you don’t have to be careful about selecting the image or other text by mistake and ruining the presentation.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>The <em>Inserter</em> Tool</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Imagine everything that WordPress can do is available to you quickly and in the same place on the interface. No need to figure out HTML tags, classes, or remember complicated shortcode syntax. That’s the spirit behind the inserter—the <code>(+)</code> button you’ll see around the editor—which allows you to browse all available content blocks and add them into your post. Plugins and themes are able to register their own, opening up all sort of possibilities for rich editing and publishing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Go give it a try, you may discover things WordPress can already add into your posts that you didn’t know about. Here’s a short list of what you can currently find there:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n	<li>Text &amp; Headings</li>\n	<li>Images &amp; Videos</li>\n	<li>Galleries</li>\n	<li>Embeds, like YouTube, Tweets, or other WordPress posts.</li>\n	<li>Layout blocks, like Buttons, Hero Images, Separators, etc.</li>\n	<li>And <em>Lists</em> like this one of course :)</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:separator -->\n<hr class=\"wp-block-separator\"/>\n<!-- /wp:separator -->\n\n<!-- wp:heading -->\n<h2>Visual Editing</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>A huge benefit of blocks is that you can edit them in place and manipulate your content directly. Instead of having fields for editing things like the source of a quote, or the text of a button, you can directly change the content. Try editing the following quote:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The editor will endeavour to create a new page and post building experience that makes writing rich posts effortless, and has “blocks” to make it easy what today might take shortcodes, custom HTML, or “mystery meat” embed discovery.</p><cite>Matt Mullenweg, 2017</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>The information corresponding to the source of the quote is a separate text field, similar to captions under images, so the structure of the quote is protected even if you select, modify, or remove the source. It’s always easy to add it back.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Blocks can be anything you need. For instance, you may want to add a subdued quote as part of the composition of your text, or you may prefer to display a giant stylized one. All of these options are available in the inserter.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"columns\":2} -->\n<ul class=\"wp-block-gallery columns-2 is-cropped\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://cldup.com/n0g6ME5VKC.jpg\" alt=\"\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://cldup.com/ZjESfxPI3R.jpg\" alt=\"\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://cldup.com/EKNF8xD2UM.jpg\" alt=\"\"/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p>You can change the amount of columns in your galleries by dragging a slider in the block inspector in the sidebar.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Media Rich</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you combine the new <strong>wide</strong> and <strong>full-wide</strong> alignments with galleries, you can create a very media rich layout, very quickly:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"align\":\"full\"} -->\n<figure class=\"wp-block-image alignfull\"><img src=\"https://cldup.com/8lhI-gKnI2.jpg\" alt=\"Accessibility is important — don’t forget image alt attribute\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sure, the full-wide image can be pretty big. But sometimes the image is worth it.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {\"align\":\"wide\"} -->\n<ul class=\"wp-block-gallery alignwide columns-2 is-cropped\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://cldup.com/_rSwtEeDGD.jpg\" alt=\"\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://cldup.com/L-cC3qX2DN.jpg\" alt=\"\"/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p>The above is a gallery with just two images. It’s an easier way to create visually appealing layouts, without having to deal with floats. You can also easily convert the gallery back to individual images again, by using the block switcher.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Any block can opt into these alignments. The embed block has them also, and is responsive out of the box:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:core-embed/vimeo {\"url\":\"https://vimeo.com/22439234\",\"type\":\"video\",\"providerNameSlug\":\"vimeo\",\"align\":\"wide\"} -->\n<figure class=\"wp-block-embed-vimeo alignwide wp-block-embed is-type-video is-provider-vimeo\">\nhttps://vimeo.com/22439234\n</figure>\n<!-- /wp:core-embed/vimeo -->\n\n<!-- wp:paragraph -->\n<p>You can build any block you like, static or dynamic, decorative or plain. Here’s a pullquote block:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:pullquote -->\n<blockquote class=\"wp-block-pullquote\"><p>Code is Poetry</p><cite>The WordPress community</cite></blockquote>\n<!-- /wp:pullquote -->\n\n<!-- wp:paragraph {\"align\":\"center\"} -->\n<p style=\"text-align:center\">\n	<em>\n		If you want to learn more about how to build additional blocks, or if you are interested in helping with the project, head over to the <a href=\"%s\">GitHub repository</a>.	</em>\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:button {\"align\":\"center\"} -->\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link\" href=\"https://github.com/WordPress/gutenberg\">Help build Gutenberg</a></div>\n<!-- /wp:button -->\n\n<!-- wp:separator -->\n<hr class=\"wp-block-separator\"/>\n<!-- /wp:separator -->\n\n<!-- wp:paragraph {\"align\":\"center\"} -->\n<p style=\"text-align:center\">Thanks for testing Gutenberg!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"align\":\"center\"} -->\n<p style=\"text-align:center\"><img draggable=\"false\" class=\"emoji\" alt=\"👋\" src=\"https://s.w.org/images/core/emoji/2.3/svg/1f44b.svg\"/></p>\n<!-- /wp:paragraph -->', 'MOT South Africa', '', 'draft', 'open', 'open', '', '', '', '', '2018-08-12 06:38:50', '2018-08-12 06:38:50', '', 0, 'http://localhost/mot/?p=5', 0, 'post', '', 0),
(7, 1, '2018-08-12 07:41:44', '2018-08-12 07:41:44', '<h2>Who we are</h2><p>Our website address is: http://localhost/mot.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2018-08-12 07:41:44', '2018-08-12 07:41:44', '', 3, 'http://localhost/mot/2018/08/12/3-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-08-12 07:42:08', '2018-08-12 07:42:08', 'MOT South Africa is a registered and leading Public Benefit and Non-Profit Organisation, specialising in life-skills development among the youth. In 2016, MOT South Africa received accreditation from the Services Seta as a Training Provider (Accreditation number 12129).\r\n\r\nIn 2017, MOT SA won the Western Cape Department of Social Development’s Ministerial Youth Excellence Silver Award in the category “Creating Youth Leaders” as well as the Mail &amp; Guardian’s “Investing in the Future” Youth Development Award. Both awards recognizes outstanding organisations who have contributed to towards youth development and best practice in their fields.\r\n\r\nMOT SA works with the youth in a structured learning environment, teaching young people to make conscious life choices that will enable them to develop to their full potential and to show courage.\r\n\r\nThe MOT training programmes give young people the strength to manage peer pressure, to believe in themselves and to take responsibility for their own lives and future. MOT focuses strongly on the development of self-confidence, sound values, positive attitude and behaviour, self-leadership and to respect and care for others.\r\n\r\nMOT partners with educational institutions, trains their staff and students as MOT Coaches and Young MOTivators, and provides the programme manuals, equipment and monitoring to ensure youth in South Africa become active citizens, leaders and role models.\r\n<h1>INTRODUCTION TO MOT</h1>\r\nThe name “MOT” was chosen because of its simple strength, and its double meaning: <strong>the Norwegian word ‘mot</strong>’ (“Moed” in Afrikaans) denotes both the ability to show courage, and the ability to take a stand against something; in this case, the prevalence of violence and drug use.\r\n\r\nMOT was introduced to South Africa in 2006 through a partnership between the College of Cape Town and the Haugaland Videregående Skole in Norway, when teachers at the College of Cape Town identified the need for a similar training programme on local soil.  Since then, the Programme Development Team has trained more than 578 MOT presenters at the seven TVET colleges<span lang=\"en\" xml:lang=\"en\"> and 18 high schools</span> in the Western Cape to present the programme locally. In May 2008 the Board of MOT South Africa was selected, and on 1 October 2008 the opening of an independent office for MOT South Africa and the appointment of the CEO, heralded a new era in the implementation of the MOT programmes in South Africa and the integration of the MOT philosophy in South African society.\r\n\r\nMOT was started by two Norwegian speed skaters, Johann Olav Koss and Atle Vårvik, at the 1994 Winter Olympic Games in Lillehammer, Norway. These two men are passionate about people, and sought, through the establishment of this programme, to strengthen the courage of the youth. On 13 April 1994 they launched a calendar project, entitled “<em>Norske</em> <em>toppidrettsutøvere mot Narkotika”</em>, or “Norwegian top athletes against narcotics”, and on 22 February 1997, during the World Skiing Championships, they took the next step by establishing MOT. The first Norwegian MOT presenters were trained during 1997, and that same year saw the introduction of the MOT programmes into several secondary schools in Norway.\r\n<h1>PURPOSE OF MOT SOUTH AFRICA</h1>\r\nThe challenges faced by young people in our fast-moving world are diverse and complex.  Our youth are faced with daily challenges and difficult situations, poverty, broken families, exposed and living with emotional, physical and substance abuse from a very early age. Often these young people are vulnerable and end up in environments and communities where the situation poses a significant risk for their emotional and physical well-being.  MOT South Africa focuses on the YOUTH and aims to improve the social environment and basic quality of young people’s lives, by teaching them essential life and social skills to effectively deal with their daily challenges.\r\n\r\nWe achieve immediate, tangible, and visible results in the lives of the youth, while at the same time affecting long-term changes in the classroom and in their communities. Through the MOT programmes, the youth is empowered with courage, resilience and life skills to make the right life choices for them to develop to their full potential and become leaders and positive role models in their communities.\r\n\r\nMOT South Africa is a registered Public Benefit Organisation (PBO No. 930 028 579) and Non-profit Organisation (NPO No: 078-690).\r\n<h1><strong>MOT PROGRAMMES</strong></h1>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">MOT has become the foundation for life-skills education at Technical and Vocational Education and Training (TVET) colleges in the Western Cape and Eastern Cape and in high schools. The programme targets youth between the ages of 12 and 25 years.  Sustained expansion will see the implementation of the MOT programmes at TVET colleges and high schools throughout South Africa.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The MOT programme for youth between the ages of 12 and 16 years, consists of 15 sessions as part of the robust youth 12 -16 programme and the programme for robust youth between 16 and 25 years, consists of 9 sessions. Both these programmes are presented over a three-year period, which contributes to the successful and sustainable outcomes of these programmes.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">At each programme session, the MOT coach (qualified by means of a three-day training course) will facilitate the students’ exploration of a particular life skill and lesson. Each session’s script is intensively researched and tested for positive outcomes, and is regularly updated by the programme development team.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The development of the MOT programmes is based on Albert Bandura’s Social Learning and Self-efficacy Theories, Urie Bronfenbrenner’s Ecological Systems Theory, as well as Alan Carr’s six human strengths, of which courage in particular is regarded as pivotal to human well-being, progress and development.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The programmes, which includes the use of practical exercises, role-play, group discussions, thought-provoking questions and general reflection on life, teach young people:</p>\r\n\r\n<ul>\r\n 	<li>How to develop greater personal insight;</li>\r\n 	<li>How to build a platform for positive relationships and to create a positive learning environment in the class;</li>\r\n 	<li>How to care for themselves and each other and to give positive feedback to one another;</li>\r\n 	<li>How to strengthen the ability to communicate, to focus on solutions and how to solve problems;</li>\r\n 	<li>Concepts like positive attitude, values, respect, dignity, integrity, choices, dreams, and believing in the future;</li>\r\n 	<li>Healthy dialogue between parents and youth;</li>\r\n 	<li>How to nurture their own development, happiness and talents;</li>\r\n 	<li>How to improve their self-esteem and develop self-confidence;</li>\r\n 	<li>How to develop the courage to speak out, to make conscious choices and to say “no”;</li>\r\n 	<li>Creative and critical thinking skills.</li>\r\n</ul>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Apart from being life-skills training programmes, MOT represents a life philosophy that we aspire to inculcate and cultivate within each individual, in institutions, communities and in society.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Read about MOT’s philosophy <a href=\"http://mot.org.za/about-mot/mot-philosophy/\">here</a>.</p>\r\n\r\n<h1>MOT NORWAY</h1>\r\nMOT Norway has a 20-year track record as a leading non-profit organisation.  MOT Norway gets its funding from the Government and major and minor collaboration partners within the private sector. Another important source of income is the program fee paid by local municipalities and colleges.\r\n\r\n<strong>Website:</strong> <a href=\"http://www.mot.no/\" target=\"_blank\" rel=\"noopener\">www.mot.no</a>\r\n\r\n<strong>MOT Norway’s office</strong>\r\n\r\nMOT Norway has grown into an organisation with 25 employees, focusing on programme development and implementation, marketing, advertising and promoting the MOT brand. <span lang=\"EN-ZA\" xml:lang=\"EN-ZA\">Currently they have 39 brand ambassadors, and <span xml:lang=\"EN-ZA\">in 2015, MOT is presented to more than 65 000 secondary and and upper secondary students to live according to the MOT values; Courage to live, Courage to care and Courage to say no.</span></span>\r\n\r\n<img class=\"size-medium wp-image-22 aligncenter\" src=\"http://localhost/mot/wp-content/uploads/2018/08/boardmotnorway-500x367-300x220.jpg\" alt=\"\" width=\"300\" height=\"220\" />\r\n\r\nBack: Therese Bjoerstad Karlsen, Roger Granheim, Vegar Kulset Front: Rune Bratseth (Chairperson), Astrid Loedemel, Marit Breivik', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-08-12 08:47:39', '2018-08-12 08:47:39', '', 0, 'http://localhost/mot/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-08-12 07:42:08', '2018-08-12 07:42:08', '', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-08-12 07:42:08', '2018-08-12 07:42:08', '', 8, 'http://localhost/mot/2018/08/12/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-08-12 07:42:22', '2018-08-12 07:42:22', '', 'Events', '', 'publish', 'closed', 'closed', '', 'events', '', '', '2018-08-12 07:42:22', '2018-08-12 07:42:22', '', 0, 'http://localhost/mot/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-08-12 07:42:22', '2018-08-12 07:42:22', '', 'Events', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-08-12 07:42:22', '2018-08-12 07:42:22', '', 10, 'http://localhost/mot/2018/08/12/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-08-12 07:42:42', '2018-08-12 07:42:42', '', 'Our Team', '', 'publish', 'closed', 'closed', '', 'our-team', '', '', '2018-08-13 13:19:39', '2018-08-13 13:19:39', '', 8, 'http://localhost/mot/?page_id=12', 0, 'page', '', 0),
(13, 1, '2018-08-12 07:42:42', '2018-08-12 07:42:42', '', 'Our Team', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-08-12 07:42:42', '2018-08-12 07:42:42', '', 12, 'http://localhost/mot/2018/08/12/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2018-08-12 07:43:14', '2018-08-12 07:43:14', '', 'MOT Ambassadors', '', 'publish', 'closed', 'closed', '', 'mot-ambassadors', '', '', '2018-08-12 07:43:14', '2018-08-12 07:43:14', '', 0, 'http://localhost/mot/?page_id=14', 0, 'page', '', 0),
(15, 1, '2018-08-12 07:43:14', '2018-08-12 07:43:14', '', 'MOT Ambassadors', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-08-12 07:43:14', '2018-08-12 07:43:14', '', 14, 'http://localhost/mot/2018/08/12/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-08-12 07:43:40', '2018-08-12 07:43:40', '', 'Donate', '', 'publish', 'closed', 'closed', '', 'donate', '', '', '2018-08-12 07:43:40', '2018-08-12 07:43:40', '', 0, 'http://localhost/mot/?page_id=16', 0, 'page', '', 0),
(17, 1, '2018-08-12 07:43:40', '2018-08-12 07:43:40', '', 'Donate', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-08-12 07:43:40', '2018-08-12 07:43:40', '', 16, 'http://localhost/mot/2018/08/12/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-08-12 07:44:35', '2018-08-12 07:44:35', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href=\"http://localhost/mot/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Our Partners', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-08-12 07:44:35', '2018-08-12 07:44:35', '', 2, 'http://localhost/mot/2018/08/12/2-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2018-08-12 07:47:00', '2018-08-12 07:47:00', '{\n    \"show_on_front\": {\n        \"value\": \"posts\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-12 07:47:00\"\n    },\n    \"page_for_posts\": {\n        \"value\": \"10\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-12 07:47:00\"\n    },\n    \"motSA::parallax_one_character_cyrillic\": {\n        \"value\": true,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-12 07:47:00\"\n    },\n    \"motSA::parallax_one_character_vietnamese\": {\n        \"value\": true,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-12 07:47:00\"\n    },\n    \"motSA::parallax_one_character_greek\": {\n        \"value\": true,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-12 07:47:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '927f03d4-988e-4959-847e-b9fd272cb7d1', '', '', '2018-08-12 07:47:00', '2018-08-12 07:47:00', '', 0, 'http://localhost/mot/2018/08/12/927f03d4-988e-4959-847e-b9fd272cb7d1/', 0, 'customize_changeset', '', 0),
(20, 1, '2018-08-12 08:46:59', '2018-08-12 08:46:59', 'MOT South Africa is a registered and leading Public Benefit and Non-Profit Organisation, specialising in life-skills development among the youth. In 2016, MOT South Africa received accreditation from the Services Seta as a Training Provider (Accreditation number 12129).\n\nIn 2017, MOT SA won the Western Cape Department of Social Development’s Ministerial Youth Excellence Silver Award in the category “Creating Youth Leaders” as well as the Mail &amp; Guardian’s “Investing in the Future” Youth Development Award. Both awards recognizes outstanding organisations who have contributed to towards youth development and best practice in their fields.\n\nMOT SA works with the youth in a structured learning environment, teaching young people to make conscious life choices that will enable them to develop to their full potential and to show courage.\n\nThe MOT training programmes give young people the strength to manage peer pressure, to believe in themselves and to take responsibility for their own lives and future. MOT focuses strongly on the development of self-confidence, sound values, positive attitude and behaviour, self-leadership and to respect and care for others.\n\nMOT partners with educational institutions, trains their staff and students as MOT Coaches and Young MOTivators, and provides the programme manuals, equipment and monitoring to ensure youth in South Africa become active citizens, leaders and role models.\n<h1>INTRODUCTION TO MOT</h1>\nThe name “MOT” was chosen because of its simple strength, and its double meaning: <strong>the Norwegian word ‘mot</strong>’ (“Moed” in Afrikaans) denotes both the ability to show courage, and the ability to take a stand against something; in this case, the prevalence of violence and drug use.\n\nMOT was introduced to South Africa in 2006 through a partnership between the College of Cape Town and the Haugaland Videregående Skole in Norway, when teachers at the College of Cape Town identified the need for a similar training programme on local soil.  Since then, the Programme Development Team has trained more than 578 MOT presenters at the seven TVET colleges<span lang=\"en\" xml:lang=\"en\"> and 18 high schools</span> in the Western Cape to present the programme locally. In May 2008 the Board of MOT South Africa was selected, and on 1 October 2008 the opening of an independent office for MOT South Africa and the appointment of the CEO, heralded a new era in the implementation of the MOT programmes in South Africa and the integration of the MOT philosophy in South African society.\n\nMOT was started by two Norwegian speed skaters, Johann Olav Koss and Atle Vårvik, at the 1994 Winter Olympic Games in Lillehammer, Norway. These two men are passionate about people, and sought, through the establishment of this programme, to strengthen the courage of the youth. On 13 April 1994 they launched a calendar project, entitled “<em>Norske</em> <em>toppidrettsutøvere mot Narkotika”</em>, or “Norwegian top athletes against narcotics”, and on 22 February 1997, during the World Skiing Championships, they took the next step by establishing MOT. The first Norwegian MOT presenters were trained during 1997, and that same year saw the introduction of the MOT programmes into several secondary schools in Norway.\n<h1>PURPOSE OF MOT SOUTH AFRICA</h1>\nThe challenges faced by young people in our fast-moving world are diverse and complex.  Our youth are faced with daily challenges and difficult situations, poverty, broken families, exposed and living with emotional, physical and substance abuse from a very early age. Often these young people are vulnerable and end up in environments and communities where the situation poses a significant risk for their emotional and physical well-being.  MOT South Africa focuses on the YOUTH and aims to improve the social environment and basic quality of young people’s lives, by teaching them essential life and social skills to effectively deal with their daily challenges.\n\nWe achieve immediate, tangible, and visible results in the lives of the youth, while at the same time affecting long-term changes in the classroom and in their communities. Through the MOT programmes, the youth is empowered with courage, resilience and life skills to make the right life choices for them to develop to their full potential and become leaders and positive role models in their communities.\n\nMOT South Africa is a registered Public Benefit Organisation (PBO No. 930 028 579) and Non-profit Organisation (NPO No: 078-690).\n<h1><strong>MOT PROGRAMMES</strong></h1>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">MOT has become the foundation for life-skills education at Technical and Vocational Education and Training (TVET) colleges in the Western Cape and Eastern Cape and in high schools. The programme targets youth between the ages of 12 and 25 years.  Sustained expansion will see the implementation of the MOT programmes at TVET colleges and high schools throughout South Africa.</p>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The MOT programme for youth between the ages of 12 and 16 years, consists of 15 sessions as part of the robust youth 12 -16 programme and the programme for robust youth between 16 and 25 years, consists of 9 sessions. Both these programmes are presented over a three-year period, which contributes to the successful and sustainable outcomes of these programmes.</p>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">At each programme session, the MOT coach (qualified by means of a three-day training course) will facilitate the students’ exploration of a particular life skill and lesson. Each session’s script is intensively researched and tested for positive outcomes, and is regularly updated by the programme development team.</p>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The development of the MOT programmes is based on Albert Bandura’s Social Learning and Self-efficacy Theories, Urie Bronfenbrenner’s Ecological Systems Theory, as well as Alan Carr’s six human strengths, of which courage in particular is regarded as pivotal to human well-being, progress and development.</p>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The programmes, which includes the use of practical exercises, role-play, group discussions, thought-provoking questions and general reflection on life, teach young people:</p>\n\n<ul>\n 	<li>How to develop greater personal insight;</li>\n 	<li>How to build a platform for positive relationships and to create a positive learning environment in the class;</li>\n 	<li>How to care for themselves and each other and to give positive feedback to one another;</li>\n 	<li>How to strengthen the ability to communicate, to focus on solutions and how to solve problems;</li>\n 	<li>Concepts like positive attitude, values, respect, dignity, integrity, choices, dreams, and believing in the future;</li>\n 	<li>Healthy dialogue between parents and youth;</li>\n 	<li>How to nurture their own development, happiness and talents;</li>\n 	<li>How to improve their self-esteem and develop self-confidence;</li>\n 	<li>How to develop the courage to speak out, to make conscious choices and to say “no”;</li>\n 	<li>Creative and critical thinking skills.</li>\n</ul>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Apart from being life-skills training programmes, MOT represents a life philosophy that we aspire to inculcate and cultivate within each individual, in institutions, communities and in society.</p>\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Read about MOT’s philosophy <a href=\"http://mot.org.za/about-mot/mot-philosophy/\">here</a>.</p>\n\n<h1>MOT NORWAY</h1>\nMOT Norway has a 20-year track record as a leading non-profit organisation.  MOT Norway gets its funding from the Government and major and minor collaboration partners within the private sector. Another important source of income is the program fee paid by local municipalities and colleges.\n\n<strong>Website:</strong> <a href=\"http://www.mot.no/\" target=\"_blank\" rel=\"noopener\">www.mot.no</a>\n\n<strong>MOT Norway’s office</strong>\n\nMOT Norway has grown into an organisation with 25 employees, focusing on programme development and implementation, marketing, advertising and promoting the MOT brand. <span lang=\"EN-ZA\" xml:lang=\"EN-ZA\">Currently they have 39 brand ambassadors, and <span xml:lang=\"EN-ZA\">in 2015, MOT is presented to more than 65 000 secondary and and upper secondary students to live according to the MOT values; Courage to live, Courage to care and Courage to say no.</span></span>\n\n&nbsp;\n\nBack: Therese Bjoerstad Karlsen, Roger Granheim, Vegar Kulset Front: Rune Bratseth (Chairperson), Astrid Loedemel, Marit Breivik', 'About', '', 'inherit', 'closed', 'closed', '', '8-autosave-v1', '', '', '2018-08-12 08:46:59', '2018-08-12 08:46:59', '', 8, 'http://localhost/mot/2018/08/12/8-autosave-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(21, 1, '2018-08-12 07:49:57', '2018-08-12 07:49:57', 'MOT South Africa is a registered and leading Public Benefit and Non-Profit Organisation, specialising in life-skills development among the youth. In 2016, MOT South Africa received accreditation from the Services Seta as a Training Provider (Accreditation number 12129).\r\n\r\nIn 2017, MOT SA won the Western Cape Department of Social Development’s Ministerial Youth Excellence Silver Award in the category “Creating Youth Leaders” as well as the Mail &amp; Guardian’s “Investing in the Future” Youth Development Award. Both awards recognizes outstanding organisations who have contributed to towards youth development and best practice in their fields.\r\n\r\nMOT SA works with the youth in a structured learning environment, teaching young people to make conscious life choices that will enable them to develop to their full potential and to show courage.\r\n\r\nThe MOT training programmes give young people the strength to manage peer pressure, to believe in themselves and to take responsibility for their own lives and future. MOT focuses strongly on the development of self-confidence, sound values, positive attitude and behaviour, self-leadership and to respect and care for others.\r\n\r\nMOT partners with educational institutions, trains their staff and students as MOT Coaches and Young MOTivators, and provides the programme manuals, equipment and monitoring to ensure youth in South Africa become active citizens, leaders and role models.\r\n<h1>INTRODUCTION TO MOT</h1>\r\nThe name “MOT” was chosen because of its simple strength, and its double meaning: <strong>the Norwegian word ‘mot</strong>’ (“Moed” in Afrikaans) denotes both the ability to show courage, and the ability to take a stand against something; in this case, the prevalence of violence and drug use.\r\n\r\nMOT was introduced to South Africa in 2006 through a partnership between the College of Cape Town and the Haugaland Videregående Skole in Norway, when teachers at the College of Cape Town identified the need for a similar training programme on local soil.  Since then, the Programme Development Team has trained more than 578 MOT presenters at the seven TVET colleges<span lang=\"en\" xml:lang=\"en\"> and 18 high schools</span> in the Western Cape to present the programme locally. In May 2008 the Board of MOT South Africa was selected, and on 1 October 2008 the opening of an independent office for MOT South Africa and the appointment of the CEO, heralded a new era in the implementation of the MOT programmes in South Africa and the integration of the MOT philosophy in South African society.\r\n\r\nMOT was started by two Norwegian speed skaters, Johann Olav Koss and Atle Vårvik, at the 1994 Winter Olympic Games in Lillehammer, Norway. These two men are passionate about people, and sought, through the establishment of this programme, to strengthen the courage of the youth. On 13 April 1994 they launched a calendar project, entitled “<em>Norske</em> <em>toppidrettsutøvere mot Narkotika”</em>, or “Norwegian top athletes against narcotics”, and on 22 February 1997, during the World Skiing Championships, they took the next step by establishing MOT. The first Norwegian MOT presenters were trained during 1997, and that same year saw the introduction of the MOT programmes into several secondary schools in Norway.\r\n<h1>PURPOSE OF MOT SOUTH AFRICA</h1>\r\nThe challenges faced by young people in our fast-moving world are diverse and complex.  Our youth are faced with daily challenges and difficult situations, poverty, broken families, exposed and living with emotional, physical and substance abuse from a very early age. Often these young people are vulnerable and end up in environments and communities where the situation poses a significant risk for their emotional and physical well-being.  MOT South Africa focuses on the YOUTH and aims to improve the social environment and basic quality of young people’s lives, by teaching them essential life and social skills to effectively deal with their daily challenges.\r\n\r\nWe achieve immediate, tangible, and visible results in the lives of the youth, while at the same time affecting long-term changes in the classroom and in their communities. Through the MOT programmes, the youth is empowered with courage, resilience and life skills to make the right life choices for them to develop to their full potential and become leaders and positive role models in their communities.\r\n\r\nMOT South Africa is a registered Public Benefit Organisation (PBO No. 930 028 579) and Non-profit Organisation (NPO No: 078-690).\r\n<h1><strong>MOT PROGRAMMES</strong></h1>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">MOT has become the foundation for life-skills education at Technical and Vocational Education and Training (TVET) colleges in the Western Cape and Eastern Cape and in high schools. The programme targets youth between the ages of 12 and 25 years.  Sustained expansion will see the implementation of the MOT programmes at TVET colleges and high schools throughout South Africa.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The MOT programme for youth between the ages of 12 and 16 years, consists of 15 sessions as part of the robust youth 12 -16 programme and the programme for robust youth between 16 and 25 years, consists of 9 sessions. Both these programmes are presented over a three-year period, which contributes to the successful and sustainable outcomes of these programmes.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">At each programme session, the MOT coach (qualified by means of a three-day training course) will facilitate the students’ exploration of a particular life skill and lesson. Each session’s script is intensively researched and tested for positive outcomes, and is regularly updated by the programme development team.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The development of the MOT programmes is based on Albert Bandura’s Social Learning and Self-efficacy Theories, Urie Bronfenbrenner’s Ecological Systems Theory, as well as Alan Carr’s six human strengths, of which courage in particular is regarded as pivotal to human well-being, progress and development.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The programmes, which includes the use of practical exercises, role-play, group discussions, thought-provoking questions and general reflection on life, teach young people:</p>\r\n\r\n<ul>\r\n 	<li>How to develop greater personal insight;</li>\r\n 	<li>How to build a platform for positive relationships and to create a positive learning environment in the class;</li>\r\n 	<li>How to care for themselves and each other and to give positive feedback to one another;</li>\r\n 	<li>How to strengthen the ability to communicate, to focus on solutions and how to solve problems;</li>\r\n 	<li>Concepts like positive attitude, values, respect, dignity, integrity, choices, dreams, and believing in the future;</li>\r\n 	<li>Healthy dialogue between parents and youth;</li>\r\n 	<li>How to nurture their own development, happiness and talents;</li>\r\n 	<li>How to improve their self-esteem and develop self-confidence;</li>\r\n 	<li>How to develop the courage to speak out, to make conscious choices and to say “no”;</li>\r\n 	<li>Creative and critical thinking skills.</li>\r\n</ul>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Apart from being life-skills training programmes, MOT represents a life philosophy that we aspire to inculcate and cultivate within each individual, in institutions, communities and in society.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Read about MOT’s philosophy <a href=\"http://mot.org.za/about-mot/mot-philosophy/\">here</a>.</p>\r\n\r\n<h1>MOT NORWAY</h1>\r\nMOT Norway has a 20-year track record as a leading non-profit organisation.  MOT Norway gets its funding from the Government and major and minor collaboration partners within the private sector. Another important source of income is the program fee paid by local municipalities and colleges.\r\n\r\n<strong>Website:</strong> <a href=\"http://www.mot.no/\" target=\"_blank\" rel=\"noopener\">www.mot.no</a>\r\n\r\n<strong>MOT Norway’s office</strong>\r\n\r\nMOT Norway has grown into an organisation with 25 employees, focusing on programme development and implementation, marketing, advertising and promoting the MOT brand. <span lang=\"EN-ZA\" xml:lang=\"EN-ZA\">Currently they have 39 brand ambassadors, and <span xml:lang=\"EN-ZA\">in 2015, MOT is presented to more than 65 000 secondary and and upper secondary students to live according to the MOT values; Courage to live, Courage to care and Courage to say no.</span></span>', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-08-12 07:49:57', '2018-08-12 07:49:57', '', 8, 'http://localhost/mot/2018/08/12/8-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-08-12 08:47:27', '2018-08-12 08:47:27', '', 'boardmotnorway-500x367', '', 'inherit', 'open', 'closed', '', 'boardmotnorway-500x367', '', '', '2018-08-12 08:47:27', '2018-08-12 08:47:27', '', 8, 'http://localhost/mot/wp-content/uploads/2018/08/boardmotnorway-500x367.jpg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2018-08-12 08:47:39', '2018-08-12 08:47:39', 'MOT South Africa is a registered and leading Public Benefit and Non-Profit Organisation, specialising in life-skills development among the youth. In 2016, MOT South Africa received accreditation from the Services Seta as a Training Provider (Accreditation number 12129).\r\n\r\nIn 2017, MOT SA won the Western Cape Department of Social Development’s Ministerial Youth Excellence Silver Award in the category “Creating Youth Leaders” as well as the Mail &amp; Guardian’s “Investing in the Future” Youth Development Award. Both awards recognizes outstanding organisations who have contributed to towards youth development and best practice in their fields.\r\n\r\nMOT SA works with the youth in a structured learning environment, teaching young people to make conscious life choices that will enable them to develop to their full potential and to show courage.\r\n\r\nThe MOT training programmes give young people the strength to manage peer pressure, to believe in themselves and to take responsibility for their own lives and future. MOT focuses strongly on the development of self-confidence, sound values, positive attitude and behaviour, self-leadership and to respect and care for others.\r\n\r\nMOT partners with educational institutions, trains their staff and students as MOT Coaches and Young MOTivators, and provides the programme manuals, equipment and monitoring to ensure youth in South Africa become active citizens, leaders and role models.\r\n<h1>INTRODUCTION TO MOT</h1>\r\nThe name “MOT” was chosen because of its simple strength, and its double meaning: <strong>the Norwegian word ‘mot</strong>’ (“Moed” in Afrikaans) denotes both the ability to show courage, and the ability to take a stand against something; in this case, the prevalence of violence and drug use.\r\n\r\nMOT was introduced to South Africa in 2006 through a partnership between the College of Cape Town and the Haugaland Videregående Skole in Norway, when teachers at the College of Cape Town identified the need for a similar training programme on local soil.  Since then, the Programme Development Team has trained more than 578 MOT presenters at the seven TVET colleges<span lang=\"en\" xml:lang=\"en\"> and 18 high schools</span> in the Western Cape to present the programme locally. In May 2008 the Board of MOT South Africa was selected, and on 1 October 2008 the opening of an independent office for MOT South Africa and the appointment of the CEO, heralded a new era in the implementation of the MOT programmes in South Africa and the integration of the MOT philosophy in South African society.\r\n\r\nMOT was started by two Norwegian speed skaters, Johann Olav Koss and Atle Vårvik, at the 1994 Winter Olympic Games in Lillehammer, Norway. These two men are passionate about people, and sought, through the establishment of this programme, to strengthen the courage of the youth. On 13 April 1994 they launched a calendar project, entitled “<em>Norske</em> <em>toppidrettsutøvere mot Narkotika”</em>, or “Norwegian top athletes against narcotics”, and on 22 February 1997, during the World Skiing Championships, they took the next step by establishing MOT. The first Norwegian MOT presenters were trained during 1997, and that same year saw the introduction of the MOT programmes into several secondary schools in Norway.\r\n<h1>PURPOSE OF MOT SOUTH AFRICA</h1>\r\nThe challenges faced by young people in our fast-moving world are diverse and complex.  Our youth are faced with daily challenges and difficult situations, poverty, broken families, exposed and living with emotional, physical and substance abuse from a very early age. Often these young people are vulnerable and end up in environments and communities where the situation poses a significant risk for their emotional and physical well-being.  MOT South Africa focuses on the YOUTH and aims to improve the social environment and basic quality of young people’s lives, by teaching them essential life and social skills to effectively deal with their daily challenges.\r\n\r\nWe achieve immediate, tangible, and visible results in the lives of the youth, while at the same time affecting long-term changes in the classroom and in their communities. Through the MOT programmes, the youth is empowered with courage, resilience and life skills to make the right life choices for them to develop to their full potential and become leaders and positive role models in their communities.\r\n\r\nMOT South Africa is a registered Public Benefit Organisation (PBO No. 930 028 579) and Non-profit Organisation (NPO No: 078-690).\r\n<h1><strong>MOT PROGRAMMES</strong></h1>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">MOT has become the foundation for life-skills education at Technical and Vocational Education and Training (TVET) colleges in the Western Cape and Eastern Cape and in high schools. The programme targets youth between the ages of 12 and 25 years.  Sustained expansion will see the implementation of the MOT programmes at TVET colleges and high schools throughout South Africa.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The MOT programme for youth between the ages of 12 and 16 years, consists of 15 sessions as part of the robust youth 12 -16 programme and the programme for robust youth between 16 and 25 years, consists of 9 sessions. Both these programmes are presented over a three-year period, which contributes to the successful and sustainable outcomes of these programmes.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">At each programme session, the MOT coach (qualified by means of a three-day training course) will facilitate the students’ exploration of a particular life skill and lesson. Each session’s script is intensively researched and tested for positive outcomes, and is regularly updated by the programme development team.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The development of the MOT programmes is based on Albert Bandura’s Social Learning and Self-efficacy Theories, Urie Bronfenbrenner’s Ecological Systems Theory, as well as Alan Carr’s six human strengths, of which courage in particular is regarded as pivotal to human well-being, progress and development.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">The programmes, which includes the use of practical exercises, role-play, group discussions, thought-provoking questions and general reflection on life, teach young people:</p>\r\n\r\n<ul>\r\n 	<li>How to develop greater personal insight;</li>\r\n 	<li>How to build a platform for positive relationships and to create a positive learning environment in the class;</li>\r\n 	<li>How to care for themselves and each other and to give positive feedback to one another;</li>\r\n 	<li>How to strengthen the ability to communicate, to focus on solutions and how to solve problems;</li>\r\n 	<li>Concepts like positive attitude, values, respect, dignity, integrity, choices, dreams, and believing in the future;</li>\r\n 	<li>Healthy dialogue between parents and youth;</li>\r\n 	<li>How to nurture their own development, happiness and talents;</li>\r\n 	<li>How to improve their self-esteem and develop self-confidence;</li>\r\n 	<li>How to develop the courage to speak out, to make conscious choices and to say “no”;</li>\r\n 	<li>Creative and critical thinking skills.</li>\r\n</ul>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Apart from being life-skills training programmes, MOT represents a life philosophy that we aspire to inculcate and cultivate within each individual, in institutions, communities and in society.</p>\r\n<p lang=\"en-US\" xml:lang=\"en-US\" align=\"justify\">Read about MOT’s philosophy <a href=\"http://mot.org.za/about-mot/mot-philosophy/\">here</a>.</p>\r\n\r\n<h1>MOT NORWAY</h1>\r\nMOT Norway has a 20-year track record as a leading non-profit organisation.  MOT Norway gets its funding from the Government and major and minor collaboration partners within the private sector. Another important source of income is the program fee paid by local municipalities and colleges.\r\n\r\n<strong>Website:</strong> <a href=\"http://www.mot.no/\" target=\"_blank\" rel=\"noopener\">www.mot.no</a>\r\n\r\n<strong>MOT Norway’s office</strong>\r\n\r\nMOT Norway has grown into an organisation with 25 employees, focusing on programme development and implementation, marketing, advertising and promoting the MOT brand. <span lang=\"EN-ZA\" xml:lang=\"EN-ZA\">Currently they have 39 brand ambassadors, and <span xml:lang=\"EN-ZA\">in 2015, MOT is presented to more than 65 000 secondary and and upper secondary students to live according to the MOT values; Courage to live, Courage to care and Courage to say no.</span></span>\r\n\r\n<img class=\"size-medium wp-image-22 aligncenter\" src=\"http://localhost/mot/wp-content/uploads/2018/08/boardmotnorway-500x367-300x220.jpg\" alt=\"\" width=\"300\" height=\"220\" />\r\n\r\nBack: Therese Bjoerstad Karlsen, Roger Granheim, Vegar Kulset Front: Rune Bratseth (Chairperson), Astrid Loedemel, Marit Breivik', 'About', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-08-12 08:47:39', '2018-08-12 08:47:39', '', 8, 'http://localhost/mot/2018/08/12/8-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2018-08-12 08:55:34', '2018-08-12 08:55:34', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2018-08-28 07:19:04', '2018-08-28 07:19:04', '', 0, 'http://localhost/mot/?p=25', 5, 'nav_menu_item', '', 0),
(26, 1, '2018-08-12 08:55:34', '2018-08-12 08:55:34', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2018-08-28 07:19:04', '2018-08-28 07:19:04', '', 8, 'http://localhost/mot/?p=26', 2, 'nav_menu_item', '', 0),
(27, 1, '2018-08-12 08:55:33', '2018-08-12 08:55:33', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2018-08-28 07:19:04', '2018-08-28 07:19:04', '', 0, 'http://localhost/mot/?p=27', 3, 'nav_menu_item', '', 0),
(28, 1, '2018-08-12 08:55:33', '2018-08-12 08:55:33', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2018-08-28 07:19:04', '2018-08-28 07:19:04', '', 0, 'http://localhost/mot/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2018-08-12 08:55:34', '2018-08-12 08:55:34', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2018-08-28 07:19:04', '2018-08-28 07:19:04', '', 0, 'http://localhost/mot/?p=29', 4, 'nav_menu_item', '', 0),
(30, 1, '2018-08-13 13:26:40', '2018-08-13 13:26:40', 'MOT South Africa is a registered and leading Public Benefit and Non-Profit Organisation, specialising in life-skills development among the youth. In 2016, MOT South Africa received accreditation from the Services Seta as a Training Provider (Accreditation number 12129).\r\n\r\nIn 2017, MOT SA won the Western Cape Department of Social Development’s Ministerial Youth Excellence Silver Award in the category “Creating Youth Leaders” as well as the Mail &amp; Guardian’s “Investing in the Future” Youth Development Award. Both awards recognizes outstanding organisations who have contributed to towards youth development and best practice in their fields.\r\n\r\nMOT SA works with the youth in a structured learning environment, teaching young people to make conscious life choices that will enable them to develop to their full potential and to show courage.\r\n\r\nThe MOT training programmes give young people the strength to manage peer pressure, to believe in themselves and to take responsibility for their own lives and future. MOT focuses strongly on the development of self-confidence, sound values, positive attitude and behaviour.', 'Blog One', '', 'publish', 'open', 'open', '', 'blog-one', '', '', '2018-08-13 13:26:40', '2018-08-13 13:26:40', '', 0, 'http://localhost/mot/?p=30', 0, 'post', '', 0),
(31, 1, '2018-08-13 13:26:40', '2018-08-13 13:26:40', 'MOT South Africa is a registered and leading Public Benefit and Non-Profit Organisation, specialising in life-skills development among the youth. In 2016, MOT South Africa received accreditation from the Services Seta as a Training Provider (Accreditation number 12129).\r\n\r\nIn 2017, MOT SA won the Western Cape Department of Social Development’s Ministerial Youth Excellence Silver Award in the category “Creating Youth Leaders” as well as the Mail &amp; Guardian’s “Investing in the Future” Youth Development Award. Both awards recognizes outstanding organisations who have contributed to towards youth development and best practice in their fields.\r\n\r\nMOT SA works with the youth in a structured learning environment, teaching young people to make conscious life choices that will enable them to develop to their full potential and to show courage.\r\n\r\nThe MOT training programmes give young people the strength to manage peer pressure, to believe in themselves and to take responsibility for their own lives and future. MOT focuses strongly on the development of self-confidence, sound values, positive attitude and behaviour.', 'Blog One', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2018-08-13 13:26:40', '2018-08-13 13:26:40', '', 30, 'http://localhost/mot/2018/08/13/30-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2018-08-28 07:05:45', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-08-28 07:05:45', '0000-00-00 00:00:00', '', 0, 'http://localhost/mot/?p=32', 0, 'post', '', 0),
(33, 1, '2018-08-28 07:10:12', '0000-00-00 00:00:00', 'dshnsjmjdsfhnjdmkfjnfmedpfkgm\r\n\r\nfdgh\r\n\r\nffasgdndfasgdnhefrwfgfhdgrafgshdjgkghfdsfgnhmbcvxzvbvnhjytrewrtyukujhgfdsfg\r\n\r\nhjgfdsasfghmnvbvxcsadfghjkiu76ytredsfghjkl;o986yrtfsdaqw23456yuilkjjmbvcxdfbnb,.l;po099876ytrewaq', 'Blog Two', '', 'draft', 'open', 'open', '', '', '', '', '2018-08-28 07:10:12', '2018-08-28 07:10:12', '', 0, 'http://localhost/mot/?p=33', 0, 'post', '', 0),
(34, 1, '2018-08-28 07:10:12', '2018-08-28 07:10:12', 'dshnsjmjdsfhnjdmkfjnfmedpfkgm\r\n\r\nfdgh\r\n\r\nffasgdndfasgdnhefrwfgfhdgrafgshdjgkghfdsfgnhmbcvxzvbvnhjytrewrtyukujhgfdsfg\r\n\r\nhjgfdsasfghmnvbvxcsadfghjkiu76ytredsfghjkl;o986yrtfsdaqw23456yuilkjjmbvcxdfbnb,.l;po099876ytrewaq', 'Blog Two', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2018-08-28 07:10:12', '2018-08-28 07:10:12', '', 33, 'http://localhost/mot/2018/08/28/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2018-08-28 07:16:55', '2018-08-28 07:16:55', 'bvhgdxfsxdgcfhjb', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-08-28 07:16:55', '2018-08-28 07:16:55', '', 0, 'http://localhost/mot/?page_id=35', 0, 'page', '', 0),
(36, 1, '2018-08-28 07:16:55', '2018-08-28 07:16:55', 'bvhgdxfsxdgcfhjb', 'Blog', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2018-08-28 07:16:55', '2018-08-28 07:16:55', '', 35, 'http://localhost/mot/2018/08/28/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-08-28 07:17:53', '2018-08-28 07:17:53', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2018-08-28 07:19:04', '2018-08-28 07:19:04', '', 0, 'http://localhost/mot/?p=37', 6, 'nav_menu_item', '', 0),
(38, 1, '2018-08-28 07:18:23', '2018-08-28 07:18:23', 'asdfgfh', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2018-08-28 07:18:23', '2018-08-28 07:18:23', '', 0, 'http://localhost/mot/?page_id=38', 0, 'page', '', 0),
(39, 1, '2018-08-28 07:18:23', '2018-08-28 07:18:23', 'asdfgfh', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2018-08-28 07:18:23', '2018-08-28 07:18:23', '', 38, 'http://localhost/mot/2018/08/28/38-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2018-08-28 07:19:05', '2018-08-28 07:19:05', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2018-08-28 07:19:05', '2018-08-28 07:19:05', '', 0, 'http://localhost/mot/?p=40', 7, 'nav_menu_item', '', 0),
(41, 1, '2018-08-28 07:22:26', '2018-08-28 07:22:26', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-08-28 07:22:26', '2018-08-28 07:22:26', '', 0, 'http://localhost/mot/?page_id=41', 0, 'page', '', 0),
(42, 1, '2018-08-28 07:22:26', '2018-08-28 07:22:26', '{\n    \"show_on_front\": {\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-28 07:22:24\"\n    },\n    \"page_on_front\": {\n        \"value\": \"41\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-28 07:22:24\"\n    },\n    \"page_for_posts\": {\n        \"value\": \"35\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-28 07:22:24\"\n    },\n    \"nav_menus_created_posts\": {\n        \"value\": [\n            41\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-28 07:22:24\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b5a0dd4e-fcc7-4ea3-95f7-2b0b4eed0fa2', '', '', '2018-08-28 07:22:26', '2018-08-28 07:22:26', '', 0, 'http://localhost/mot/?p=42', 0, 'customize_changeset', '', 0),
(43, 1, '2018-08-28 07:22:26', '2018-08-28 07:22:26', '', 'Home', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2018-08-28 07:22:26', '2018-08-28 07:22:26', '', 41, 'http://localhost/mot/?p=43', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Primary Menu', 'primary-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 1, 0),
(25, 2, 0),
(26, 2, 0),
(27, 2, 0),
(28, 2, 0),
(29, 2, 0),
(30, 1, 0),
(33, 1, 0),
(37, 2, 0),
(40, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'motadmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"f859adca8c671b32a8e3dc46d406a6fd4f4377345ed236a7573ed4478bbc21da\";a:4:{s:10:\"expiration\";i:1535612744;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36\";s:5:\"login\";i:1535439944;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '32'),
(18, 1, 'show_try_gutenberg_panel', '0'),
(19, 1, 'wp_user-settings', 'libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1534063655'),
(21, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}'),
(23, 1, 'nav_menu_recently_edited', '2');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'motadmin', '$P$Bj/xsFf4/6ADJtB56Y1YE2VDCYIqHo/', 'motadmin', 'shuaib.allie@yahoo.com', '', '2018-08-12 06:36:56', '', 0, 'motadmin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
